from setuptools import setup

setup(
    name='neurosky',
    python_requires='>3.6.0',
    version='0.0.1',
    packages=[''],
    url='',
    license='MIT',
    author='Bituhh',
    author_email='victor@bituhh.com',
    description=''
)
